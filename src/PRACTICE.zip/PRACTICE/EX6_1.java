package PRACTICE;

public class EX6_1<T> {
	
	//An object of type T is declared
	
	T obj;
	
	//contructor
	EX6_1(T obj){
		this.obj = obj;
	}
	
	public T getObject() {
		return this.obj;
	}

}
